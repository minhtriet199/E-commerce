<?php

namespace App\Http\Services\Menu;
use App\Models\Menus;
use App\Models\Product;
use App\Http\Requests\Menu\UpdateRequest;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;

class MenuService
{
    public function get()
    {
        return Menus::all();
    }
    public function create($request)
    {
        try{
            Menus::create([
                'name' =>$request->input('name'),
                'active' =>$request->input('active'),
                'slug' =>Str::slug($request->input('name'),'-')
            ]);

            Session::flash('success','Tạo danh mục thành công');
        }
        catch(\Exception $err){
            Session::flash('error',$err->getMessage());
            return false;
        }
        return true;
    }

    public function update($request, $menus) : bool
    {   
        $menus->name = $request->input('name');
        $menus->active = $request->input('active');
        $menus->slug = Str::slug($request->input('name'),'-');
        $menus->save();
        
        Session::flash('success','Cập nhật danh mục thành công');
        return true;
    }
    
    public function destroy($request)
    {
        $menu = Menus::where('id',$request->input('id'))->first(); 
        if($menu){
            $menu -> delete();
            return true;
        }
        return false;
    }

    public function getSlug($slug)
    {
        return Menus::where('slug',$slug)->firstOrFail();
    }
}

